 <!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <?php include 'movie_carousel.php' ?>
            </div>
        </header>
